import { useState, type ReactNode } from "react";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Bell,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  CreditCard,
  FileText,
  Grid2X2,
  Landmark,
  LayoutDashboard,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserRound,
  X,
} from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const navItems: Array<[string, ReactNode]> = [
  ["Overview", <LayoutDashboard size={18} />],
  ["Payments", <Send size={18} />],
  ["Transactions", <FileText size={18} />],
  ["Cards", <CreditCard size={18} />],
  ["Insights", <TrendingUp size={18} />],
];
const manageItems: Array<[string, ReactNode]> = [
  ["Accounts", <Landmark size={18} />],
  ["Settings", <Settings2 size={18} />],
];
const pathToLabel: Record<string, string> = {
  "/payments": "Payments",
  "/transactions": "Transactions",
  "/cards": "Cards",
  "/insights": "Insights",
  "/accounts": "Accounts",
  "/settings": "Settings",
};

function LogoMark() {
  return (
    <div className="logo-mark" aria-label="Aurora Banking">
      <span />
      <span />
      <span />
    </div>
  );
}

function PageHeader({
  eyebrow,
  title,
  copy,
  action,
}: {
  eyebrow: string;
  title: string;
  copy: string;
  action?: ReactNode;
}) {
  return (
    <section className="route-hero page-enter">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p>{copy}</p>
      </div>
      {action}
    </section>
  );
}

function StatusPill({
  children,
  tone = "green",
}: {
  children: ReactNode;
  tone?: "green" | "purple" | "orange";
}) {
  return <span className={`status-pill ${tone}`}>{children}</span>;
}

function PaymentsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Payments center"
        title="Move money with confidence"
        copy="Everything you need to send, schedule, and receive money in one calm workspace."
        action={
          <button
            className="primary-btn"
            onClick={() =>
              toast.success("New payment started", {
                description: "Choose a recipient to continue.",
              })
            }
          >
            <Plus size={17} /> New payment
          </button>
        }
      />
      <div className="route-grid route-grid-payments">
        <article className="panel feature-panel">
          <div className="feature-icon mint-tile">
            <Send size={21} />
          </div>
          <p className="eyebrow">Fast transfer</p>
          <h2>Send money</h2>
          <p>
            Move money to a person or one of your linked accounts. Most
            transfers arrive instantly.
          </p>
          <button
            className="text-btn"
            onClick={() =>
              toast("Recipient list opened", {
                description: "Maya Rodriguez is your most recent recipient.",
              })
            }
          >
            Choose recipient <ChevronRight size={14} />
          </button>
        </article>
        <article className="panel feature-panel">
          <div className="feature-icon purple-tile">
            <FileText size={21} />
          </div>
          <p className="eyebrow">Household essentials</p>
          <h2>Pay a bill</h2>
          <p>
            Keep utilities, cards, and monthly commitments on track with one
            secure view.
          </p>
          <button
            className="text-btn"
            onClick={() =>
              toast("Bill pay opened", {
                description: "3 saved payees are ready.",
              })
            }
          >
            View payees <ChevronRight size={14} />
          </button>
        </article>
        <article className="panel feature-panel">
          <div className="feature-icon orange-tile">
            <ArrowDownLeft size={21} />
          </div>
          <p className="eyebrow">Add funds</p>
          <h2>Deposit a check</h2>
          <p>
            Deposit checks from your phone with secure mobile capture and
            instant status updates.
          </p>
          <button
            className="text-btn"
            onClick={() =>
              toast("Mobile deposit", {
                description: "Open Aurora on your phone to scan a check.",
              })
            }
          >
            How it works <ChevronRight size={14} />
          </button>
        </article>
      </div>
      <div className="route-grid two-col-grid">
        <article className="panel route-table-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Coming up</p>
              <h2>Scheduled payments</h2>
            </div>
            <button
              className="more-btn"
              onClick={() =>
                toast("Payment templates", {
                  description: "Your recurring payment templates are ready.",
                })
              }
            >
              <MoreHorizontal size={19} />
            </button>
          </div>
          <div className="schedule-list">
            <div className="schedule-item">
              <div className="schedule-date">
                <strong>01</strong>
                <span>OCT</span>
              </div>
              <div>
                <strong>Monthly rent</strong>
                <span>Checking · •••• 4821</span>
              </div>
              <b>$2,400.00</b>
              <StatusPill>In 9 days</StatusPill>
            </div>
            <div className="schedule-item">
              <div className="schedule-date">
                <strong>03</strong>
                <span>OCT</span>
              </div>
              <div>
                <strong>Electric company</strong>
                <span>Checking · •••• 4821</span>
              </div>
              <b>$126.80</b>
              <StatusPill tone="purple">In 11 days</StatusPill>
            </div>
            <div className="schedule-item">
              <div className="schedule-date">
                <strong>08</strong>
                <span>OCT</span>
              </div>
              <div>
                <strong>Cloud storage</strong>
                <span>Visa · •••• 9012</span>
              </div>
              <b>$12.00</b>
              <StatusPill tone="orange">In 16 days</StatusPill>
            </div>
          </div>
        </article>
        <article className="panel route-side-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Your people</p>
              <h2>Recent recipients</h2>
            </div>
            <button className="more-btn">
              <Plus size={18} />
            </button>
          </div>
          <div className="recipient-list">
            <div>
              <span className="avatar avatar-recipient">MR</span>
              <span>
                <strong>Maya Rodriguez</strong>
                <small>Checking · •••• 4821</small>
              </span>
              <ChevronRight size={16} />
            </div>
            <div>
              <span className="avatar avatar-small avatar-blue">LP</span>
              <span>
                <strong>Lena Park</strong>
                <small>Savings · •••• 0194</small>
              </span>
              <ChevronRight size={16} />
            </div>
            <div>
              <span className="avatar avatar-small avatar-purple">NW</span>
              <span>
                <strong>Northwind Studio</strong>
                <small>Business · •••• 7008</small>
              </span>
              <ChevronRight size={16} />
            </div>
          </div>
        </article>
      </div>
    </>
  );
}

function TransactionsPage() {
  const rows = [
    "Maya Rodriguez",
    "Whole Foods Market",
    "Lena Park",
    "Northwind Studio",
    "Horizon Air",
    "City Power & Light",
    "Brightline Coffee",
  ];
  return (
    <>
      <PageHeader
        eyebrow="Activity center"
        title="Every transaction, in focus"
        copy="Search, filter, and understand the movement across all your Aurora accounts."
        action={
          <button
            className="secondary-btn"
            onClick={() =>
              toast("Export ready", {
                description: "Your transaction CSV is being prepared.",
              })
            }
          >
            <FileText size={16} /> Export CSV
          </button>
        }
      />
      <article className="panel route-table-panel full-route-panel">
        <div className="transaction-toolbar">
          <div className="search-field">
            <Search size={16} />
            <input placeholder="Search transactions, merchants, or notes" />
          </div>
          <button
            className="filter-btn"
            onClick={() =>
              toast("Filters", {
                description: "Date, account, and category filters are ready.",
              })
            }
          >
            Filter <ChevronDown size={14} />
          </button>
        </div>
        <div className="transaction-tabs">
          <button className="selected">
            All activity <span>24</span>
          </button>
          <button>
            Money in <span>8</span>
          </button>
          <button>
            Money out <span>16</span>
          </button>
          <button>
            Recurring <span>5</span>
          </button>
        </div>
        <div className="route-transaction-list">
          {rows.map((name, index) => {
            const incoming = index === 0 || index === 3;
            const icons = [
              <ArrowDownLeft size={17} />,
              <Grid2X2 size={17} />,
              <Send size={17} />,
              <BriefcaseBusiness size={17} />,
              <Sparkles size={17} />,
              <Landmark size={17} />,
              <CircleHelp size={17} />,
            ];
            return (
              <div className="route-transaction-row" key={name}>
                <div
                  className={`transaction-icon ${["green", "purple", "orange", "blue", "pink", "purple", "blue"][index]}`}
                >
                  {icons[index]}
                </div>
                <div className="transaction-name">
                  <strong>{name}</strong>
                  <span>
                    {incoming
                      ? "Transfer · Checking • 4821"
                      : "Card payment · Visa • 9012"}
                  </span>
                </div>
                <span className="transaction-date">
                  {index < 2
                    ? "Today"
                    : index < 5
                      ? "Yesterday"
                      : "Sep 17, 2026"}
                </span>
                <strong
                  className={`transaction-amount ${incoming ? "income" : ""}`}
                >
                  {incoming
                    ? "+$1,250.00"
                    : `-$${["86.42", "240.00", "428.90", "142.18", "24.00"][index - 1] || "18.40"}`}
                </strong>
                <button
                  className="row-more"
                  aria-label="More transaction options"
                  onClick={() =>
                    toast(name, {
                      description:
                        "Transaction details are available in secure view.",
                    })
                  }
                >
                  <MoreHorizontal size={17} />
                </button>
              </div>
            );
          })}
        </div>
        <div className="pagination-row">
          <span>Showing 1–7 of 24 transactions</span>
          <div>
            <button className="selected">1</button>
            <button>2</button>
            <button>3</button>
            <button>
              Next <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </article>
    </>
  );
}

function CardsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Card studio"
        title="Your cards, your control"
        copy="Manage spending, limits, and security for every Aurora card."
        action={
          <button
            className="primary-btn"
            onClick={() =>
              toast("New card request", {
                description: "Choose a card design to continue.",
              })
            }
          >
            <Plus size={17} /> Add a card
          </button>
        }
      />
      <div className="cards-layout">
        <article className="panel card-detail-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Primary card</p>
              <h2>Everyday spending</h2>
            </div>
            <StatusPill>Active</StatusPill>
          </div>
          <div className="bank-card big-bank-card">
            <div className="card-top">
              <span className="card-brand">aurora</span>
              <span className="card-type">VISA</span>
            </div>
            <div className="card-number">
              •••• &nbsp; •••• &nbsp; •••• &nbsp; 9012
            </div>
            <div className="card-bottom">
              <span>Alex Rivera</span>
              <span>09/29</span>
            </div>
            <div className="card-shine" />
          </div>
          <div className="card-controls">
            <button
              onClick={() =>
                toast("Card frozen", {
                  description: "This is a reversible demo action.",
                })
              }
            >
              <ShieldCheck size={16} /> Freeze card
            </button>
            <button
              onClick={() =>
                toast("Card details protected", {
                  description: "Use SecureSign to reveal sensitive details.",
                })
              }
            >
              <EyeIcon /> Show details
            </button>
            <button
              onClick={() =>
                toast("Card settings", {
                  description: "Spending controls are ready.",
                })
              }
            >
              <Settings2 size={16} /> Settings
            </button>
          </div>
        </article>
        <div className="card-stat-stack">
          <article className="panel stat-panel">
            <p className="eyebrow">Monthly spending</p>
            <strong>
              $2,180.40 <small>/ $5,000</small>
            </strong>
            <div className="limit-bar">
              <span />
            </div>
            <div className="stat-foot">
              <span>43.6% used</span>
              <span>$2,819.60 left</span>
            </div>
          </article>
          <article className="panel stat-panel">
            <p className="eyebrow">Cashback earned</p>
            <strong>$84.20</strong>
            <p className="stat-copy">
              <TrendingUp size={14} /> +$18.40 this month
            </p>
          </article>
          <article className="panel stat-panel">
            <p className="eyebrow">Last charged</p>
            <strong>$428.90</strong>
            <p className="stat-copy">Horizon Air · Sep 19, 2026</p>
          </article>
        </div>
      </div>
      <article className="panel route-table-panel card-table-panel">
        <div className="panel-heading">
          <div>
            <p className="eyebrow">All cards</p>
            <h2>Card portfolio</h2>
          </div>
          <button className="text-btn">
            Manage cards <ChevronRight size={14} />
          </button>
        </div>
        <div className="mini-card-row">
          <span className="mini-card mini-card-dark" />
          <div>
            <strong>Everyday spending</strong>
            <small>Visa · •••• 9012</small>
          </div>
          <StatusPill>Active</StatusPill>
          <ChevronRight size={16} />
        </div>
        <div className="mini-card-row">
          <span className="mini-card mini-card-plum" />
          <div>
            <strong>Travel reserve</strong>
            <small>Visa · •••• 2274</small>
          </div>
          <StatusPill tone="purple">Active</StatusPill>
          <ChevronRight size={16} />
        </div>
      </article>
    </>
  );
}

function InsightsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Financial intelligence"
        title="See the pattern behind the numbers"
        copy="Aurora turns your everyday activity into clear, useful decisions."
        action={
          <button
            className="secondary-btn"
            onClick={() =>
              toast("Insight report", {
                description: "Your monthly financial report is ready to view.",
              })
            }
          >
            <FileText size={16} /> Monthly report
          </button>
        }
      />
      <div className="insights-hero-grid">
        <article className="panel insight-score-panel">
          <div className="score-ring">
            <span>82</span>
            <small>/100</small>
          </div>
          <div>
            <p className="eyebrow">Financial wellness</p>
            <h2>Looking strong, Alex.</h2>
            <p>
              You’re saving more consistently and your recurring costs are
              trending down.
            </p>
            <StatusPill>+6 pts this month</StatusPill>
          </div>
        </article>
        <article className="panel savings-panel">
          <p className="eyebrow">Savings progress</p>
          <div className="savings-number">
            $18,420 <span>of $24,000 goal</span>
          </div>
          <div className="big-progress">
            <span />
          </div>
          <div className="stat-foot">
            <span>76.7% complete</span>
            <strong>92 days left</strong>
          </div>
        </article>
      </div>
      <div className="route-grid insights-grid">
        <article className="panel route-table-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">Spending mix</p>
              <h2>Where your money goes</h2>
            </div>
            <button className="more-btn">
              <MoreHorizontal size={19} />
            </button>
          </div>
          <div className="category-bars">
            <div>
              <span>
                <i className="category-dot dot-purple" /> Home & utilities
              </span>
              <b>32%</b>
              <div>
                <i style={{ width: "32%" }} />
              </div>
            </div>
            <div>
              <span>
                <i className="category-dot dot-mint" /> Food & dining
              </span>
              <b>21%</b>
              <div>
                <i style={{ width: "21%" }} />
              </div>
            </div>
            <div>
              <span>
                <i className="category-dot dot-orange" /> Travel
              </span>
              <b>18%</b>
              <div>
                <i style={{ width: "18%" }} />
              </div>
            </div>
            <div>
              <span>
                <i className="category-dot dot-blue" /> Shopping
              </span>
              <b>15%</b>
              <div>
                <i style={{ width: "15%" }} />
              </div>
            </div>
            <div>
              <span>
                <i className="category-dot dot-pink" /> Other
              </span>
              <b>14%</b>
              <div>
                <i style={{ width: "14%" }} />
              </div>
            </div>
          </div>
        </article>
        <article className="panel route-table-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">This month</p>
              <h2>Notable moments</h2>
            </div>
          </div>
          <div className="moment-list">
            <div>
              <span className="moment-icon mint-tile">
                <TrendingUp size={16} />
              </span>
              <p>
                <strong>Lower dining spend</strong>
                <small>You’re $142 below your monthly average.</small>
              </p>
            </div>
            <div>
              <span className="moment-icon purple-tile">
                <Sparkles size={16} />
              </span>
              <p>
                <strong>Subscription check</strong>
                <small>One unused subscription renewed this week.</small>
              </p>
            </div>
            <div>
              <span className="moment-icon orange-tile">
                <BriefcaseBusiness size={16} />
              </span>
              <p>
                <strong>Income is on track</strong>
                <small>18% more income than this time last month.</small>
              </p>
            </div>
          </div>
        </article>
      </div>
    </>
  );
}

function AccountsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Account center"
        title="A clear view of what you own"
        copy="Organize cash, savings, and longer-term goals across Aurora."
        action={
          <button
            className="primary-btn"
            onClick={() =>
              toast("Account opening", {
                description: "Choose a new Aurora account to get started.",
              })
            }
          >
            <Plus size={17} /> Open account
          </button>
        }
      />
      <div className="account-total panel">
        <div>
          <p className="eyebrow">Combined balance</p>
          <h2>$48,294.62</h2>
          <span className="positive">
            <TrendingUp size={14} /> +12.8% from last month
          </span>
        </div>
        <div className="account-total-orb">
          <Landmark size={28} />
        </div>
      </div>
      <div className="account-grid">
        <article className="panel account-card">
          <div className="account-card-top">
            <span className="account-icon mint-tile">
              <Landmark size={19} />
            </span>
            <StatusPill>Primary</StatusPill>
          </div>
          <p className="eyebrow">Everyday checking</p>
          <h2>$12,840.22</h2>
          <p>Available to spend</p>
          <footer>
            <span>•••• 4821</span>
            <button>
              Details <ChevronRight size={14} />
            </button>
          </footer>
        </article>
        <article className="panel account-card account-card-purple">
          <div className="account-card-top">
            <span className="account-icon purple-tile">
              <Sparkles size={19} />
            </span>
            <StatusPill tone="purple">Goal</StatusPill>
          </div>
          <p className="eyebrow">Future home fund</p>
          <h2>$18,420.00</h2>
          <p>76.7% of your goal</p>
          <footer>
            <span>•••• 0194</span>
            <button>
              Details <ChevronRight size={14} />
            </button>
          </footer>
        </article>
        <article className="panel account-card account-card-orange">
          <div className="account-card-top">
            <span className="account-icon orange-tile">
              <BriefcaseBusiness size={19} />
            </span>
            <StatusPill tone="orange">Business</StatusPill>
          </div>
          <p className="eyebrow">Northwind business</p>
          <h2>$17,034.40</h2>
          <p>Operating balance</p>
          <footer>
            <span>•••• 7008</span>
            <button>
              Details <ChevronRight size={14} />
            </button>
          </footer>
        </article>
      </div>
    </>
  );
}

function SettingsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Preferences"
        title="Make Aurora yours"
        copy="Personalize your experience and keep your account protected."
        action={
          <button
            className="secondary-btn"
            onClick={() =>
              toast.success("Preferences saved", {
                description: "Your settings are up to date.",
              })
            }
          >
            <Check size={16} /> Save changes
          </button>
        }
      />
      <div className="settings-layout">
        <aside className="panel settings-nav">
          <button className="selected">
            <UserRound size={17} /> Profile
          </button>
          <button>
            <ShieldCheck size={17} /> Security
          </button>
          <button>
            <Bell size={17} /> Notifications
          </button>
          <button>
            <Settings2 size={17} /> Preferences
          </button>
        </aside>
        <div className="settings-content">
          <article className="panel settings-panel">
            <div className="panel-heading">
              <div>
                <p className="eyebrow">Personal profile</p>
                <h2>How Aurora knows you</h2>
              </div>
              <button className="text-btn">
                Edit <ChevronRight size={14} />
              </button>
            </div>
            <div className="profile-row">
              <div className="top-avatar large-profile">AR</div>
              <div>
                <strong>Alex Rivera</strong>
                <span>alex.rivera@example.com</span>
                <small>Member since April 2018</small>
              </div>
            </div>
            <div className="settings-fields">
              <label>
                Full name
                <input value="Alex Rivera" readOnly />
              </label>
              <label>
                Email address
                <input value="alex.rivera@example.com" readOnly />
              </label>
              <label>
                Phone number
                <input value="+1 (415) 555-0198" readOnly />
              </label>
              <label>
                Time zone
                <input value="Pacific Time (PT)" readOnly />
              </label>
            </div>
          </article>
          <article className="panel settings-panel">
            <div className="panel-heading">
              <div>
                <p className="eyebrow">Security status</p>
                <h2>Your account is protected</h2>
              </div>
              <StatusPill>Excellent</StatusPill>
            </div>
            <div className="security-row">
              <ShieldCheck size={18} />
              <div>
                <strong>Two-step verification</strong>
                <span>Authenticator app · Last checked today</span>
              </div>
              <button className="toggle-on">
                <i />
              </button>
            </div>
            <div className="security-row">
              <Bell size={18} />
              <div>
                <strong>Login alerts</strong>
                <span>Get notified about new sign-ins</span>
              </div>
              <button className="toggle-on">
                <i />
              </button>
            </div>
          </article>
        </div>
      </div>
    </>
  );
}

function EyeIcon() {
  return <Search size={16} />;
}

function PageContent({ label }: { label: string }) {
  if (label === "Payments") return <PaymentsPage />;
  if (label === "Transactions") return <TransactionsPage />;
  if (label === "Cards") return <CardsPage />;
  if (label === "Insights") return <InsightsPage />;
  if (label === "Accounts") return <AccountsPage />;
  return <SettingsPage />;
}

export default function SectionPage({ page }: { page: string }) {
  const [, setLocation] = useLocation();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const activeLabel = pathToLabel[page] ?? "Payments";
  const changeNav = (label: string) => {
    setMobileNavOpen(false);
    setLocation(label === "Overview" ? "/" : `/${label.toLowerCase()}`);
  };
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <div className="brand-row">
          <LogoMark />
          <div className="brand-copy">
            <strong>aurora</strong>
            <span>private banking</span>
          </div>
          <button
            className="mobile-close"
            aria-label="Close navigation"
            onClick={() => setMobileNavOpen(false)}
          >
            <X size={19} />
          </button>
        </div>
        <div className="workspace-switcher">
          <div className="avatar avatar-small">AR</div>
          <div>
            <span>Personal space</span>
            <strong>Alex Rivera</strong>
          </div>
          <ChevronDown size={15} />
        </div>
        <nav className="primary-nav" aria-label="Primary navigation">
          <p className="nav-label">Workspace</p>
          {navItems.map(([label, icon]) => (
            <button
              key={label}
              className={`nav-item ${activeLabel === label ? "active" : ""}`}
              onClick={() => changeNav(label)}
            >
              <span className="nav-icon">{icon}</span>
              <span>{label}</span>
              {label === "Payments" && <span className="nav-dot" />}
            </button>
          ))}
          <p className="nav-label nav-label-spaced">Manage</p>
          {manageItems.map(([label, icon]) => (
            <button
              key={label}
              className={`nav-item ${activeLabel === label ? "active" : ""}`}
              onClick={() => changeNav(label)}
            >
              <span className="nav-icon">{icon}</span>
              <span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-spacer" />
        <div className="support-card">
          <div className="support-icon">
            <CircleHelp size={18} />
          </div>
          <strong>Need a hand?</strong>
          <p>Our concierge team is online 24/7.</p>
          <button
            onClick={() =>
              toast("Concierge requested", {
                description: "A specialist will appear in the secure inbox.",
              })
            }
          >
            Open secure inbox <ChevronRight size={14} />
          </button>
        </div>
        <div className="sidebar-footer">
          <ShieldCheck size={14} /> FDIC insured · Member since 2018
        </div>
      </aside>
      {mobileNavOpen && (
        <button
          className="nav-overlay"
          aria-label="Close navigation overlay"
          onClick={() => setMobileNavOpen(false)}
        />
      )}
      <main className="main-pane">
        <header className="topbar">
          <button
            className="mobile-menu"
            aria-label="Open navigation"
            onClick={() => setMobileNavOpen(true)}
          >
            <Menu size={21} />
          </button>
          <div className="breadcrumbs">
            <span>Personal space</span>
            <ChevronRight size={14} />
            <strong>{activeLabel}</strong>
          </div>
          <div className="topbar-actions">
            <div className="secure-pill">
              <ShieldCheck size={14} /> <span>Secure session</span>
            </div>
            <button
              className="icon-btn"
              aria-label="Search"
              onClick={() =>
                toast("Search is ready", {
                  description: "Search this workspace from the secure view.",
                })
              }
            >
              <Search size={18} />
            </button>
            <button
              className="icon-btn"
              aria-label="Notifications"
              onClick={() =>
                toast("You’re all caught up", {
                  description: "No new account alerts right now.",
                })
              }
            >
              <Bell size={18} />
              <span className="notification-dot" />
            </button>
            <div className="top-avatar">AR</div>
          </div>
        </header>
        <div className="content-wrap route-content">
          <PageContent label={activeLabel} />
          <footer className="page-footer">
            <span>© 2026 Aurora Financial, N.A.</span>
            <span>
              <ShieldCheck size={13} /> Bank-grade encryption
            </span>
            <button
              onClick={() =>
                toast("Help center", {
                  description:
                    "Support articles are available in the secure inbox.",
                })
              }
            >
              Privacy & security
            </button>
          </footer>
        </div>
      </main>
    </div>
  );
}
