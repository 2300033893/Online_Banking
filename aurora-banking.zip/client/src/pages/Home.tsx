import { useMemo, useState, type ReactNode } from "react";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  CreditCard,
  Eye,
  EyeOff,
  FileText,
  Filter,
  Gift,
  Grid2X2,
  Landmark,
  LayoutDashboard,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserRound,
  WalletCards,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { formatCurrency, isValidTransferAmount } from "@/lib/banking";
import { useLocation } from "wouter";

type Transaction = {
  name: string;
  meta: string;
  date: string;
  amount: string;
  value: number;
  icon: ReactNode;
  tone: "green" | "purple" | "orange" | "blue" | "pink";
  kind: "income" | "expense";
};

const transactions: Transaction[] = [
  {
    name: "Maya Rodriguez",
    meta: "Transfer · Checking • 4821",
    date: "Today, 10:42 AM",
    amount: "+$1,250.00",
    value: 1250,
    icon: <ArrowDownLeft size={17} />,
    tone: "green",
    kind: "income",
  },
  {
    name: "Whole Foods Market",
    meta: "Groceries · Debit • 1990",
    date: "Today, 08:18 AM",
    amount: "-$86.42",
    value: -86.42,
    icon: <Grid2X2 size={17} />,
    tone: "purple",
    kind: "expense",
  },
  {
    name: "Lena Park",
    meta: "Transfer · Savings • 0194",
    date: "Yesterday, 4:16 PM",
    amount: "-$240.00",
    value: -240,
    icon: <Send size={17} />,
    tone: "orange",
    kind: "expense",
  },
  {
    name: "Northwind Studio",
    meta: "Invoice #NW-2048 · Checking",
    date: "Yesterday, 11:03 AM",
    amount: "+$3,840.00",
    value: 3840,
    icon: <BriefcaseBusiness size={17} />,
    tone: "blue",
    kind: "income",
  },
  {
    name: "Horizon Air",
    meta: "Travel · Visa • 9012",
    date: "Sep 19, 2026",
    amount: "-$428.90",
    value: -428.9,
    icon: <Sparkles size={17} />,
    tone: "pink",
    kind: "expense",
  },
];

const chartPaths = {
  "30d":
    "M0 146 C35 144 48 113 78 121 C106 129 112 100 145 104 C176 109 183 72 211 83 C239 94 247 51 273 66 C304 84 313 47 342 50 C371 53 386 24 418 35 C444 44 461 13 490 22 C514 29 526 10 560 14",
  "90d":
    "M0 145 C37 136 53 121 78 127 C105 133 113 108 146 118 C173 128 189 91 214 101 C243 113 254 82 277 85 C305 88 320 52 345 64 C373 76 391 31 420 46 C450 60 468 24 495 35 C521 45 538 16 560 20",
  "7d": "M0 143 C31 140 49 92 81 112 C108 129 123 108 147 118 C174 129 179 83 207 92 C236 102 252 45 275 70 C301 98 326 60 350 67 C380 75 397 22 424 44 C452 66 469 32 493 34 C520 37 537 15 560 19",
};

function LogoMark() {
  return (
    <div className="logo-mark" aria-label="Aurora Banking">
      <span />
      <span />
      <span />
    </div>
  );
}

function IconButton({
  children,
  label,
  onClick,
}: {
  children: ReactNode;
  label: string;
  onClick?: () => void;
}) {
  return (
    <button className="icon-btn" aria-label={label} onClick={onClick}>
      {children}
    </button>
  );
}

function SectionTitle({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h2>{title}</h2>
      </div>
      {action}
    </div>
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [activeNav, setActiveNav] = useState("Overview");
  const [range, setRange] = useState<keyof typeof chartPaths>("30d");
  const [filter, setFilter] = useState<"all" | "income" | "expense">("all");
  const [showBalance, setShowBalance] = useState(true);
  const [sendOpen, setSendOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [sendAmount, setSendAmount] = useState("");

  const visibleTransactions = useMemo(() => {
    if (filter === "all") return transactions;
    return transactions.filter(transaction => transaction.kind === filter);
  }, [filter]);

  const changeNav = (label: string) => {
    setActiveNav(label);
    setMobileNavOpen(false);
    setLocation(label === "Overview" ? "/" : `/${label.toLowerCase()}`);
  };

  const submitTransfer = () => {
    if (!isValidTransferAmount(sendAmount)) {
      toast.error("Enter an amount to continue", {
        description: "Use any positive amount for this demo.",
      });
      return;
    }
    setSendOpen(false);
    setSendAmount("");
    toast.success("Transfer queued", {
      description: `$${formatCurrency(Number(sendAmount))} is ready for review.`,
    });
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <div className="brand-row">
          <LogoMark />
          <div className="brand-copy">
            <strong>aurora</strong>
            <span>private banking</span>
          </div>
          <button
            className="mobile-close"
            aria-label="Close navigation"
            onClick={() => setMobileNavOpen(false)}
          >
            <X size={19} />
          </button>
        </div>

        <div className="workspace-switcher">
          <div className="avatar avatar-small">AR</div>
          <div>
            <span>Personal space</span>
            <strong>Alex Rivera</strong>
          </div>
          <ChevronDown size={15} />
        </div>

        <nav className="primary-nav" aria-label="Primary navigation">
          <p className="nav-label">Workspace</p>
          {[
            ["Overview", <LayoutDashboard size={18} />],
            ["Payments", <Send size={18} />],
            ["Transactions", <FileText size={18} />],
            ["Cards", <CreditCard size={18} />],
            ["Insights", <TrendingUp size={18} />],
          ].map(([label, icon]) => (
            <button
              key={label as string}
              className={`nav-item ${activeNav === label ? "active" : ""}`}
              onClick={() => changeNav(label as string)}
            >
              <span className="nav-icon">{icon}</span>
              <span>{label}</span>
              {label === "Payments" && <span className="nav-dot" />}
            </button>
          ))}
          <p className="nav-label nav-label-spaced">Manage</p>
          {[
            ["Accounts", <Landmark size={18} />],
            ["Settings", <Settings2 size={18} />],
          ].map(([label, icon]) => (
            <button
              key={label as string}
              className={`nav-item ${activeNav === label ? "active" : ""}`}
              onClick={() => changeNav(label as string)}
            >
              <span className="nav-icon">{icon}</span>
              <span>{label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-spacer" />
        <div className="support-card">
          <div className="support-icon">
            <CircleHelp size={18} />
          </div>
          <strong>Need a hand?</strong>
          <p>Our concierge team is online 24/7.</p>
          <button
            onClick={() =>
              toast("Concierge requested", {
                description: "A specialist will appear in the secure inbox.",
              })
            }
          >
            Open secure inbox <ChevronRight size={14} />
          </button>
        </div>
        <div className="sidebar-footer">
          <ShieldCheck size={14} /> FDIC insured · Member since 2018
        </div>
      </aside>

      {mobileNavOpen && (
        <button
          className="nav-overlay"
          aria-label="Close navigation overlay"
          onClick={() => setMobileNavOpen(false)}
        />
      )}

      <main className="main-pane">
        <header className="topbar">
          <button
            className="mobile-menu"
            aria-label="Open navigation"
            onClick={() => setMobileNavOpen(true)}
          >
            <Menu size={21} />
          </button>
          <div className="breadcrumbs">
            <span>Personal space</span>
            <ChevronRight size={14} />
            <strong>{activeNav}</strong>
          </div>
          <div className="topbar-actions">
            <div className="secure-pill">
              <ShieldCheck size={14} /> <span>Secure session</span>
            </div>
            <IconButton
              label="Search"
              onClick={() =>
                toast("Search is ready", {
                  description:
                    "Try searching transactions, payees, or help articles.",
                })
              }
            >
              <Search size={18} />
            </IconButton>
            <IconButton
              label="Notifications"
              onClick={() =>
                toast("You’re all caught up", {
                  description: "No new account alerts right now.",
                })
              }
            >
              <Bell size={18} />
              <span className="notification-dot" />
            </IconButton>
            <div className="top-avatar">AR</div>
          </div>
        </header>

        <div className="content-wrap">
          <section className="welcome-row page-enter">
            <div>
              <p className="eyebrow">
                Monday, September 22, 2026 <span className="live-dot" /> Live
                overview
              </p>
              <h1>
                Good morning, Alex<span className="wave">✦</span>
              </h1>
              <p className="welcome-copy">
                Here’s your complete financial picture, beautifully organized.
              </p>
            </div>
            <div className="welcome-actions">
              <button
                className="secondary-btn"
                onClick={() =>
                  toast("Statement export started", {
                    description:
                      "Your September statement will be ready shortly.",
                  })
                }
              >
                <FileText size={16} /> Statements
              </button>
              <button className="primary-btn" onClick={() => setSendOpen(true)}>
                <Plus size={17} /> Move money
              </button>
            </div>
          </section>

          <section className="metric-grid page-enter stagger-1">
            <article className="metric-card balance-card">
              <div className="metric-top">
                <span className="metric-label">Total balance</span>
                <button
                  className="visibility-btn"
                  onClick={() => setShowBalance(!showBalance)}
                  aria-label={showBalance ? "Hide balance" : "Show balance"}
                >
                  {showBalance ? <Eye size={17} /> : <EyeOff size={17} />}
                </button>
              </div>
              <div className="balance-value">
                {showBalance ? "$48,294.62" : "••••••••"}
              </div>
              <div className="balance-meta">
                <span className="positive">
                  <TrendingUp size={14} /> +12.8%
                </span>
                <span>vs. last month</span>
              </div>
              <div className="balance-orb orb-one" />
              <div className="balance-orb orb-two" />
              <div className="balance-footer">
                <span>Available to spend</span>
                <strong>{showBalance ? "$12,840.22" : "••••••"}</strong>
              </div>
            </article>
            <article className="metric-card light-card">
              <div className="metric-top">
                <span className="metric-label">Money in</span>
                <span className="metric-icon green-icon">
                  <ArrowDownLeft size={16} />
                </span>
              </div>
              <div className="metric-value">
                $8,420<span>.00</span>
              </div>
              <div className="metric-meta">
                <span className="positive">+18.4%</span>
                <span>this month</span>
              </div>
              <div className="mini-bars green-bars">
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
              </div>
            </article>
            <article className="metric-card light-card">
              <div className="metric-top">
                <span className="metric-label">Money out</span>
                <span className="metric-icon purple-icon">
                  <ArrowUpRight size={16} />
                </span>
              </div>
              <div className="metric-value">
                $3,186<span>.24</span>
              </div>
              <div className="metric-meta">
                <span className="purple-text">-4.2%</span>
                <span>vs. budget</span>
              </div>
              <div className="mini-bars purple-bars">
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
                <i />
              </div>
            </article>
          </section>

          <section className="primary-grid page-enter stagger-2">
            <article className="panel chart-panel">
              <div className="panel-heading">
                <div>
                  <p className="eyebrow">Cash flow</p>
                  <h2>Balance overview</h2>
                </div>
                <div className="range-switcher">
                  {(
                    [
                      ["7d", "7D"],
                      ["30d", "30D"],
                      ["90d", "90D"],
                    ] as const
                  ).map(([key, label]) => (
                    <button
                      key={key}
                      className={range === key ? "selected" : ""}
                      onClick={() => setRange(key)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="chart-summary">
                <strong>$48,294.62</strong>
                <span className="positive">
                  <TrendingUp size={14} /> $5,482.20 <small>this period</small>
                </span>
              </div>
              <div className="chart-wrap">
                <div className="chart-y-labels">
                  <span>$50k</span>
                  <span>$40k</span>
                  <span>$30k</span>
                  <span>$20k</span>
                  <span>$10k</span>
                  <span>$0</span>
                </div>
                <svg
                  className="balance-chart"
                  viewBox="0 0 560 180"
                  role="img"
                  aria-label="Balance trend chart"
                >
                  <defs>
                    <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8fe5b2" stopOpacity=".38" />
                      <stop offset="100%" stopColor="#8fe5b2" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <g className="grid-lines">
                    <line x1="0" y1="0" x2="560" y2="0" />
                    <line x1="0" y1="36" x2="560" y2="36" />
                    <line x1="0" y1="72" x2="560" y2="72" />
                    <line x1="0" y1="108" x2="560" y2="108" />
                    <line x1="0" y1="144" x2="560" y2="144" />
                    <line x1="0" y1="179" x2="560" y2="179" />
                  </g>
                  <path
                    d={`${chartPaths[range]} L560 180 L0 180 Z`}
                    fill="url(#chartFill)"
                  />
                  <path
                    d={chartPaths[range]}
                    fill="none"
                    stroke="#5cbf87"
                    strokeWidth="3"
                    strokeLinecap="round"
                  />
                  <circle
                    cx="560"
                    cy={range === "7d" ? "19" : range === "30d" ? "14" : "20"}
                    r="5"
                    fill="#fff"
                    stroke="#5cbf87"
                    strokeWidth="3"
                  />
                </svg>
                <div className="chart-x-labels">
                  <span>Sep 01</span>
                  <span>Sep 08</span>
                  <span>Sep 15</span>
                  <span>Sep 22</span>
                </div>
              </div>
              <div className="chart-legend">
                <span>
                  <i className="legend-dot mint-dot" /> Total balance
                </span>
                <span>
                  <i className="legend-dot navy-dot" /> Available to spend
                </span>
                <button
                  onClick={() =>
                    toast("Insights ready", {
                      description:
                        "You’re trending 8% above your 90-day average.",
                    })
                  }
                >
                  View insights <ChevronRight size={14} />
                </button>
              </div>
            </article>

            <article className="panel move-panel">
              <div className="panel-heading">
                <div>
                  <p className="eyebrow">Quick actions</p>
                  <h2>Move money</h2>
                </div>
                <button
                  className="more-btn"
                  aria-label="More actions"
                  onClick={() =>
                    toast("More actions", {
                      description:
                        "Scheduled transfers and wire templates are available in Payments.",
                    })
                  }
                >
                  <MoreHorizontal size={19} />
                </button>
              </div>
              <p className="panel-copy">
                Make a transfer, pay a bill, or add funds in a few taps.
              </p>
              <button className="action-tile" onClick={() => setSendOpen(true)}>
                <span className="action-tile-icon mint-tile">
                  <Send size={18} />
                </span>
                <span>
                  <strong>Send money</strong>
                  <small>To a person or account</small>
                </span>
                <ChevronRight size={17} />
              </button>
              <button
                className="action-tile"
                onClick={() =>
                  toast("Pay a bill", {
                    description: "Bill pay setup is ready for your payees.",
                  })
                }
              >
                <span className="action-tile-icon purple-tile">
                  <FileText size={18} />
                </span>
                <span>
                  <strong>Pay a bill</strong>
                  <small>Utilities, cards, and more</small>
                </span>
                <ChevronRight size={17} />
              </button>
              <button
                className="action-tile"
                onClick={() =>
                  toast("Deposit a check", {
                    description:
                      "Camera deposit is available in the mobile app.",
                  })
                }
              >
                <span className="action-tile-icon orange-tile">
                  <ArrowDownLeft size={18} />
                </span>
                <span>
                  <strong>Deposit a check</strong>
                  <small>Scan from your phone</small>
                </span>
                <ChevronRight size={17} />
              </button>
              <div className="scheduled-row">
                <div className="calendar-icon">
                  <CalendarDays size={16} />
                </div>
                <div>
                  <strong>Next scheduled</strong>
                  <span>Rent · Oct 01 · $2,400.00</span>
                </div>
                <span className="scheduled-status">In 9 days</span>
              </div>
            </article>
          </section>

          <section className="lower-grid page-enter stagger-3">
            <article className="panel transactions-panel">
              <div className="panel-heading">
                <div>
                  <p className="eyebrow">Activity</p>
                  <h2>Recent transactions</h2>
                </div>
                <button
                  className="text-btn"
                  onClick={() => changeNav("Transactions")}
                >
                  View all <ChevronRight size={14} />
                </button>
              </div>
              <div className="table-tools">
                <div className="tab-switcher">
                  {(
                    [
                      ["all", "All activity"],
                      ["income", "Money in"],
                      ["expense", "Money out"],
                    ] as const
                  ).map(([key, label]) => (
                    <button
                      key={key}
                      className={filter === key ? "selected" : ""}
                      onClick={() => setFilter(key)}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                <button
                  className="filter-btn"
                  onClick={() =>
                    toast("Filters", {
                      description:
                        "Date, account, and category filters are available in the full view.",
                    })
                  }
                >
                  <Filter size={14} /> Filter
                </button>
              </div>
              <div className="transaction-list">
                {visibleTransactions.map(transaction => (
                  <div
                    className="transaction-row"
                    key={`${transaction.name}-${transaction.date}`}
                  >
                    <div className={`transaction-icon ${transaction.tone}`}>
                      {transaction.icon}
                    </div>
                    <div className="transaction-name">
                      <strong>{transaction.name}</strong>
                      <span>{transaction.meta}</span>
                    </div>
                    <div className="transaction-date">{transaction.date}</div>
                    <strong
                      className={`transaction-amount ${transaction.kind === "income" ? "income" : ""}`}
                    >
                      {transaction.amount}
                    </strong>
                    <button
                      className="row-more"
                      aria-label={`More options for ${transaction.name}`}
                      onClick={() =>
                        toast(transaction.name, {
                          description:
                            "Transaction details are available in the secure view.",
                        })
                      }
                    >
                      <MoreHorizontal size={17} />
                    </button>
                  </div>
                ))}
              </div>
            </article>

            <div className="side-stack">
              <article className="panel card-preview-panel">
                <div className="panel-heading">
                  <div>
                    <p className="eyebrow">Your cards</p>
                    <h2>Everyday spending</h2>
                  </div>
                  <button
                    className="more-btn"
                    onClick={() => changeNav("Cards")}
                    aria-label="Open cards"
                  >
                    <ChevronRight size={18} />
                  </button>
                </div>
                <div className="bank-card">
                  <div className="card-top">
                    <span className="card-brand">aurora</span>
                    <span className="card-type">VISA</span>
                  </div>
                  <div className="card-number">
                    •••• &nbsp; •••• &nbsp; •••• &nbsp; 9012
                  </div>
                  <div className="card-bottom">
                    <span>Alex Rivera</span>
                    <span>09/29</span>
                  </div>
                  <div className="card-shine" />
                </div>
                <div className="card-limit">
                  <div>
                    <span>Monthly spend</span>
                    <strong>
                      $2,180.40 <small>/ $5,000</small>
                    </strong>
                  </div>
                  <span className="limit-percent">43.6%</span>
                </div>
                <div className="limit-bar">
                  <span />
                </div>
              </article>
              <article className="panel insight-panel">
                <div className="insight-spark">
                  <Sparkles size={18} />
                </div>
                <div>
                  <p className="eyebrow">Smart insight</p>
                  <h3>You’re on a roll</h3>
                  <p>
                    Your spending is 12% lower than your average Tuesday. Keep
                    the momentum going.
                  </p>
                  <button onClick={() => changeNav("Insights")}>
                    Explore insights <ChevronRight size={14} />
                  </button>
                </div>
              </article>
            </div>
          </section>

          <footer className="page-footer">
            <span>© 2026 Aurora Financial, N.A.</span>
            <span>
              <ShieldCheck size={13} /> Bank-grade encryption
            </span>
            <button
              onClick={() =>
                toast("Help center", {
                  description:
                    "Support articles are available in the secure inbox.",
                })
              }
            >
              Privacy & security
            </button>
          </footer>
        </div>
      </main>

      {sendOpen && (
        <div className="modal-backdrop" onMouseDown={() => setSendOpen(false)}>
          <div
            className="transfer-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="transfer-title"
            onMouseDown={event => event.stopPropagation()}
          >
            <div className="modal-header">
              <div>
                <p className="eyebrow">Secure transfer</p>
                <h2 id="transfer-title">Send money</h2>
              </div>
              <button
                className="modal-close"
                onClick={() => setSendOpen(false)}
                aria-label="Close transfer dialog"
              >
                <X size={19} />
              </button>
            </div>
            <div className="recipient-card">
              <div className="avatar avatar-recipient">MR</div>
              <div>
                <strong>Maya Rodriguez</strong>
                <span>Checking · •••• 4821</span>
              </div>
              <Check size={17} />
            </div>
            <label className="amount-label" htmlFor="amount">
              Amount
            </label>
            <div className="amount-input">
              <span>$</span>
              <input
                id="amount"
                type="number"
                inputMode="decimal"
                placeholder="0.00"
                value={sendAmount}
                onChange={event => setSendAmount(event.target.value)}
                autoFocus
              />
            </div>
            <div className="transfer-note">
              <ShieldCheck size={15} />
              <span>Transfers are protected by Aurora SecureSign.</span>
            </div>
            <button
              className="primary-btn modal-submit"
              onClick={submitTransfer}
            >
              Review transfer <ChevronRight size={16} />
            </button>
            <button className="cancel-btn" onClick={() => setSendOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export function DemoBadge() {
  return (
    <span className="demo-badge">
      <Gift size={13} /> Demo workspace
    </span>
  );
}

export function UserMenuIcon() {
  return <UserRound size={18} />;
}

export function WalletIcon() {
  return <WalletCards size={18} />;
}
