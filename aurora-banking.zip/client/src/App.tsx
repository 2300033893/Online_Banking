import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import SectionPage from "./pages/SectionPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/payments">
        <SectionPage page="/payments" />
      </Route>
      <Route path="/transactions">
        <SectionPage page="/transactions" />
      </Route>
      <Route path="/cards">
        <SectionPage page="/cards" />
      </Route>
      <Route path="/insights">
        <SectionPage page="/insights" />
      </Route>
      <Route path="/accounts">
        <SectionPage page="/accounts" />
      </Route>
      <Route path="/settings">
        <SectionPage page="/settings" />
      </Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
